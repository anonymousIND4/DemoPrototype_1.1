// JavaScript for the Crop Recommendation Form

document.addEventListener('DOMContentLoaded', function() {
    const cropRecommendationForm = document.getElementById('cropRecommendationForm');
    const loadingSection = document.getElementById('loadingSection');
    const resultsSection = document.getElementById('resultsSection');
    const resultCard = document.getElementById('resultCard');
    const newRecommendationBtn = document.getElementById('newRecommendationBtn');

    if (cropRecommendationForm) {
        cropRecommendationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const nitrogen = document.getElementById('nitrogen').value;
            const phosphorus = document.getElementById('phosphorus').value;
            const potassium = document.getElementById('potassium').value;
            const ph = document.getElementById('ph').value;
            const rainfall = document.getElementById('rainfall').value;
            const temperature = document.getElementById('temperature').value;
            const humidity = document.getElementById('humidity').value;
            
            // Validate inputs
            if (!nitrogen || !phosphorus || !potassium || !ph || !rainfall || !temperature || !humidity) {
                alert('Please fill in all fields');
                return;
            }
            
            // Show loading section
            cropRecommendationForm.style.display = 'none';
            loadingSection.style.display = 'block';
            
            // Simulate API call delay (3 seconds)
            setTimeout(function() {
                // Hide loading section
                loadingSection.style.display = 'none';
                
                // Process the recommendation (this would normally be done by an AI model)
                const recommendedCrop = getRecommendedCrop(nitrogen, phosphorus, potassium, ph, rainfall, temperature, humidity);
                
                // Display the result
                displayResult(recommendedCrop);
                
                // Show results section
                resultsSection.style.display = 'block';
                
                // Save input values to localStorage for results page
                saveInputValues({
                    nitrogen,
                    phosphorus,
                    potassium,
                    ph,
                    rainfall,
                    temperature,
                    humidity
                });
            }, 3000);
        });
    }

    if (newRecommendationBtn) {
        newRecommendationBtn.addEventListener('click', function() {
            // Hide results section
            resultsSection.style.display = 'none';
            // Show form again
            cropRecommendationForm.style.display = 'block';
            // Reset form
            cropRecommendationForm.reset();
        });
    }

    // Function to determine the recommended crop based on input values
    // This is a simplified version - in a real application, this would be replaced by an AI model
    function getRecommendedCrop(nitrogen, phosphorus, potassium, ph, rainfall, temperature, humidity) {
        // Convert inputs to numbers
        nitrogen = parseFloat(nitrogen);
        phosphorus = parseFloat(phosphorus);
        potassium = parseFloat(potassium);
        ph = parseFloat(ph);
        rainfall = parseFloat(rainfall);
        temperature = parseFloat(temperature);
        humidity = parseFloat(humidity);
        
        // Simple rule-based system for demonstration
        // In a real application, this would be replaced by a machine learning model
        
        // Rice conditions
        if (nitrogen > 80 && phosphorus > 40 && potassium > 40 && temperature > 22 && temperature < 32 && humidity > 80 && rainfall > 200) {
            return {
                name: 'Rice',
                image: 'images/crops/rice.jpg',
                description: 'Rice is a staple food crop that thrives in warm, humid conditions with abundant water. It is well-suited to your soil conditions and environmental factors.',
                confidence: 92
            };
        }
        
        // Wheat conditions
        else if (nitrogen > 60 && phosphorus > 30 && potassium > 30 && temperature > 15 && temperature < 25 && humidity > 40 && humidity < 70) {
            return {
                name: 'Wheat',
                image: 'images/crops/wheat.jpg',
                description: 'Wheat is a cereal grain that grows well in moderate temperatures and medium humidity. Your soil composition is ideal for wheat cultivation.',
                confidence: 88
            };
        }
        
        // Maize/Corn conditions
        else if (nitrogen > 80 && phosphorus > 50 && potassium > 30 && temperature > 20 && temperature < 30 && rainfall > 80 && rainfall < 200) {
            return {
                name: 'Maize (Corn)',
                image: 'images/crops/maize.jpg',
                description: 'Maize is a versatile crop that requires good nitrogen levels and moderate rainfall. Your conditions are favorable for corn production.',
                confidence: 85
            };
        }
        
        // Cotton conditions
        else if (nitrogen > 50 && phosphorus > 25 && potassium > 50 && temperature > 25 && rainfall > 80 && rainfall < 150 && ph > 5.5 && ph < 8) {
            return {
                name: 'Cotton',
                image: 'images/crops/cotton.jpg',
                description: 'Cotton is a cash crop that thrives in warm weather with moderate rainfall. Your soil pH and nutrient levels are suitable for cotton farming.',
                confidence: 80
            };
        }
        
        // Sugarcane conditions
        else if (nitrogen > 70 && phosphorus > 50 && potassium > 50 && temperature > 24 && temperature < 35 && humidity > 70 && rainfall > 150) {
            return {
                name: 'Sugarcane',
                image: 'images/crops/sugarcane.jpg',
                description: 'Sugarcane is a tropical crop that requires high temperatures, humidity, and rainfall. Your conditions are well-suited for sugarcane cultivation.',
                confidence: 87
            };
        }
        
        // Default recommendation if no specific match
        else {
            // Determine which crop might be closest based on a simple scoring system
            let scores = {
                rice: 0,
                wheat: 0,
                maize: 0,
                cotton: 0,
                sugarcane: 0
            };
            
            // Add points based on how close the values are to ideal conditions
            // This is a very simplified approach
            
            // Default to a general recommendation
            return {
                name: 'Mixed Vegetables',
                image: 'images/crops/vegetables.jpg',
                description: 'Based on your soil and environmental conditions, a variety of vegetables could be suitable. Consider crops like tomatoes, peppers, or leafy greens that can adapt to different conditions.',
                confidence: 70
            };
        }
    }

    // Function to display the recommendation result
    function displayResult(crop) {
        if (!resultCard) return;
        
        resultCard.innerHTML = `
            <img src="${crop.image}" alt="${crop.name}" onerror="this.src='images/crops/default.jpg'">
            <h3>${crop.name}</h3>
            <div class="confidence-meter">
                <span>Confidence: ${crop.confidence}%</span>
                <div class="meter">
                    <div class="meter-fill" style="width: ${crop.confidence}%"></div>
                </div>
            </div>
            <p>${crop.description}</p>
            <a href="results.html" class="btn btn-primary">View Detailed Information</a>
        `;
    }

    // Function to save input values to localStorage
    function saveInputValues(values) {
        localStorage.setItem('cropInputs', JSON.stringify(values));
    }
});