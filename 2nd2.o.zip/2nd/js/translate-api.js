/**
 * LibreTranslate API Integration
 * This file provides integration with the LibreTranslate API for automatic translation
 * of website content.
 */

// Configuration for LibreTranslate API
const LIBRETRANSLATE_API_URL = 'https://libretranslate.de/translate'; // Public instance
// You can also use other public instances like:
// - https://translate.argosopentech.com/translate
// - https://translate.terraprint.co/translate

/**
 * Translates text using the LibreTranslate API
 * @param {string} text - The text to translate
 * @param {string} sourceLang - The source language code (e.g., 'en', 'hi')
 * @param {string} targetLang - The target language code (e.g., 'en', 'hi')
 * @returns {Promise<string>} - The translated text
 */
async function translateText(text, sourceLang, targetLang) {
    try {
        // Don't translate if source and target languages are the same
        if (sourceLang === targetLang) {
            return text;
        }
        
        const response = await fetch(LIBRETRANSLATE_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                q: text,
                source: sourceLang,
                target: targetLang,
                format: 'text',
                api_key: '' // Leave empty for public instances
            })
        });
        
        if (!response.ok) {
            throw new Error(`Translation API error: ${response.status}`);
        }
        
        const data = await response.json();
        return data.translatedText;
    } catch (error) {
        console.error('Translation error:', error);
        return text; // Return original text on error
    }
}

/**
 * Translates all elements with data-i18n attributes using the API
 * @param {string} targetLang - The target language code
 */
async function translatePageWithAPI(targetLang) {
    // Show loading indicator
    showTranslationLoading(true);
    
    try {
        const elements = document.querySelectorAll('[data-i18n]');
        const sourceLang = 'en'; // Assuming English is the source language
        
        for (const element of elements) {
            const key = element.getAttribute('data-i18n');
            const originalText = translations['en'][key];
            
            if (originalText) {
                // Only translate if we don't already have a translation
                if (!translations[targetLang] || !translations[targetLang][key]) {
                    const translatedText = await translateText(originalText, sourceLang, targetLang);
                    
                    // Store the translation for future use
                    if (!translations[targetLang]) {
                        translations[targetLang] = {};
                    }
                    translations[targetLang][key] = translatedText;
                    
                    // Update the element with the translated text
                    if (element.tagName === 'INPUT' && element.type === 'submit') {
                        element.value = translatedText;
                    } else if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                        element.placeholder = translatedText;
                    } else {
                        element.textContent = translatedText;
                    }
                }
            }
        }
        
        // Update the current language display
        const currentLangElement = document.querySelector('.current-lang');
        if (currentLangElement) {
            currentLangElement.textContent = targetLang.toUpperCase();
        }
        
        // Update active language in dropdown
        updateActiveLanguage(targetLang);
        
        // Store the selected language
        localStorage.setItem('language', targetLang);
        currentLang = targetLang;
    } catch (error) {
        console.error('Page translation error:', error);
    } finally {
        // Hide loading indicator
        showTranslationLoading(false);
    }
}

/**
 * Shows or hides a loading indicator during translation
 * @param {boolean} isLoading - Whether translation is in progress
 */
function showTranslationLoading(isLoading) {
    let loadingElement = document.getElementById('translation-loading');
    
    if (isLoading) {
        if (!loadingElement) {
            loadingElement = document.createElement('div');
            loadingElement.id = 'translation-loading';
            loadingElement.innerHTML = `
                <div class="loading-spinner"></div>
                <div class="loading-text">Translating...</div>
            `;
            document.body.appendChild(loadingElement);
        }
        loadingElement.style.display = 'flex';
    } else if (loadingElement) {
        loadingElement.style.display = 'none';
    }
}

/**
 * Add API translation button to the language selector
 */
document.addEventListener('DOMContentLoaded', function() {
    // Add CSS for the loading indicator
    const style = document.createElement('style');
    style.textContent = `
        #translation-loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            color: white;
        }
        
        .loading-spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid white;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin-bottom: 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loading-text {
            font-size: 16px;
            font-weight: bold;
        }
        
        .api-translate-btn {
            display: block;
            margin-top: 10px;
            padding: 8px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            font-weight: bold;
        }
        
        .api-translate-btn:hover {
            background-color: #45a049;
        }
    `;
    document.head.appendChild(style);
    
    // Add API translation button to the language dropdown
    const langDropdown = document.querySelector('.lang-dropdown');
    if (langDropdown) {
        const apiTranslateBtn = document.createElement('button');
        apiTranslateBtn.className = 'api-translate-btn';
        apiTranslateBtn.textContent = 'Auto-Translate';
        apiTranslateBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            const selectedLang = document.querySelector('.lang-dropdown li.active').getAttribute('data-lang');
            translatePageWithAPI(selectedLang);
            // Close dropdown after selection
            document.querySelector('.lang-dropdown').style.display = 'none';
        });
        langDropdown.appendChild(apiTranslateBtn);
    }
});