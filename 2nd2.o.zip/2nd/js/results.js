// JavaScript for the Results Page

document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const cropImage = document.getElementById('cropImage');
    const cropName = document.getElementById('cropName');
    const cropScientific = document.getElementById('cropScientific');
    const matchScore = document.getElementById('matchScore');
    const matchPercent = document.getElementById('matchPercent');
    const cropDescription = document.getElementById('cropDescription');
    const idealTemp = document.getElementById('idealTemp');
    const waterNeeds = document.getElementById('waterNeeds');
    const growingSeason = document.getElementById('growingSeason');
    const sunlightNeeds = document.getElementById('sunlightNeeds');
    const farmingTips = document.getElementById('farmingTips');
    
    // Input summary elements
    const inputN = document.getElementById('inputN');
    const inputP = document.getElementById('inputP');
    const inputK = document.getElementById('inputK');
    const inputPH = document.getElementById('inputPH');
    const inputRainfall = document.getElementById('inputRainfall');
    const inputTemp = document.getElementById('inputTemp');
    const inputHumidity = document.getElementById('inputHumidity');
    
    // Get saved input values from localStorage
    const savedInputs = JSON.parse(localStorage.getItem('cropInputs')) || {};
    
    // Display input values if available
    if (Object.keys(savedInputs).length > 0) {
        inputN.textContent = `${savedInputs.nitrogen} kg/ha`;
        inputP.textContent = `${savedInputs.phosphorus} kg/ha`;
        inputK.textContent = `${savedInputs.potassium} kg/ha`;
        inputPH.textContent = savedInputs.ph;
        inputRainfall.textContent = `${savedInputs.rainfall} mm`;
        inputTemp.textContent = `${savedInputs.temperature} °C`;
        inputHumidity.textContent = `${savedInputs.humidity}%`;
    }
    
    // Crop database (in a real application, this would come from a server)
    const cropDatabase = {
        'Rice': {
            scientific: 'Oryza sativa',
            description: 'Rice is one of the most important food crops in the world, particularly in Asia where it is a staple food. It grows in paddy fields and requires significant amounts of water. Rice thrives in warm, humid conditions with good irrigation systems.',
            temperature: '20-35°C',
            water: 'High',
            season: '100-150 days',
            sunlight: 'Full sun',
            tips: [
                'Prepare the soil by plowing and harrowing to ensure it\'s level for even water distribution.',
                'Maintain water levels at 2-5 cm during the growing period.',
                'Apply fertilizers in split doses for better nutrient uptake.',
                'Monitor for pests like stem borers and diseases like blast.',
                'Harvest when 80-85% of the grains have turned golden yellow.'
            ]
        },
        'Wheat': {
            scientific: 'Triticum aestivum',
            description: 'Wheat is a cereal grain that is a worldwide staple food. It is the second most-produced cereal crop after maize. Wheat grows best in well-drained soil with moderate water and sunlight.',
            temperature: '15-24°C',
            water: 'Moderate',
            season: '100-130 days',
            sunlight: 'Full sun',
            tips: [
                'Plant wheat in well-drained soil with good water-holding capacity.',
                'Ensure proper seed depth (2-5 cm) for optimal germination.',
                'Apply nitrogen fertilizer in split applications.',
                'Control weeds early in the growing season.',
                'Monitor for rust diseases and aphid infestations.'
            ]
        },
        'Maize (Corn)': {
            scientific: 'Zea mays',
            description: 'Maize, also known as corn, is a cereal grain first domesticated by indigenous peoples in southern Mexico. It has become a staple food in many parts of the world, with total production surpassing that of wheat or rice.',
            temperature: '20-30°C',
            water: 'Moderate to High',
            season: '90-120 days',
            sunlight: 'Full sun',
            tips: [
                'Plant when soil temperatures reach at least 16°C for good germination.',
                'Space plants appropriately (15-20 cm within rows, 75-90 cm between rows).',
                'Apply nitrogen fertilizer when plants are knee-high.',
                'Ensure consistent moisture, especially during tasseling and ear formation.',
                'Control weeds early as corn is a poor competitor in its early stages.'
            ]
        },
        'Cotton': {
            scientific: 'Gossypium hirsutum',
            description: 'Cotton is a soft, fluffy staple fiber that grows in a boll around the seeds of cotton plants. It is a cash crop valued for its fiber used in textiles. Cotton requires a long frost-free period, plenty of sunshine, and moderate rainfall.',
            temperature: '25-35°C',
            water: 'Moderate',
            season: '150-180 days',
            sunlight: 'Full sun',
            tips: [
                'Plant in well-drained soil with good organic matter content.',
                'Maintain soil pH between 5.8-8.0.',
                'Apply balanced fertilizers based on soil test results.',
                'Monitor for bollworms, aphids, and boll weevils.',
                'Harvest when bolls are fully open but before fiber quality deteriorates.'
            ]
        },
        'Sugarcane': {
            scientific: 'Saccharum officinarum',
            description: 'Sugarcane is a tall perennial grass that is primarily cultivated for its juice, from which sugar is processed. It requires a tropical or subtropical climate, with a minimum of 600 mm of annual moisture.',
            temperature: '24-35°C',
            water: 'High',
            season: '10-12 months',
            sunlight: 'Full sun',
            tips: [
                'Plant in deep, well-drained soils with good water-holding capacity.',
                'Apply organic matter before planting to improve soil structure.',
                'Ensure adequate irrigation, especially during the formative phase.',
                'Control weeds during the first 3-4 months of growth.',
                'Monitor for pests like borers and diseases like red rot.'
            ]
        },
        'Mixed Vegetables': {
            scientific: 'Various species',
            description: 'Growing a variety of vegetables can be a good strategy when soil conditions are suitable for multiple crops. This approach can help diversify income sources and reduce risk from crop-specific pests or diseases.',
            temperature: '15-30°C (varies by crop)',
            water: 'Varies by crop',
            season: '30-120 days (varies by crop)',
            sunlight: 'Full to partial sun',
            tips: [
                'Consider crop rotation to improve soil health and reduce pest pressure.',
                'Group vegetables with similar water and nutrient requirements together.',
                'Use companion planting to naturally deter pests.',
                'Implement drip irrigation for water efficiency.',
                'Consider raised beds for better drainage and soil management.'
            ]
        }
    };
    
    // Get the crop name from URL parameter or default to Rice
    const urlParams = new URLSearchParams(window.location.search);
    const cropNameParam = urlParams.get('crop') || 'Rice';
    
    // Get crop data
    const cropData = cropDatabase[cropNameParam] || cropDatabase['Rice'];
    
    // Get confidence score from localStorage or default to 85
    const confidenceScore = parseInt(localStorage.getItem('cropConfidence')) || 85;
    
    // Update the UI with crop data
    if (cropName) cropName.textContent = cropNameParam;
    if (cropScientific) cropScientific.textContent = cropData.scientific;
    if (cropDescription) cropDescription.textContent = cropData.description;
    if (idealTemp) idealTemp.textContent = cropData.temperature;
    if (waterNeeds) waterNeeds.textContent = cropData.water;
    if (growingSeason) growingSeason.textContent = cropData.season;
    if (sunlightNeeds) sunlightNeeds.textContent = cropData.sunlight;
    
    // Update match score
    if (matchScore) matchScore.style.width = `${confidenceScore}%`;
    if (matchPercent) matchPercent.textContent = `${confidenceScore}%`;
    
    // Update crop image
    if (cropImage) {
        cropImage.src = `images/crops/${cropNameParam.toLowerCase().replace(/\s+\([^)]*\)/g, '').replace(/\s+/g, '')}.jpg`;
        cropImage.alt = cropNameParam;
        
        // Handle image loading error
        cropImage.onerror = function() {
            this.src = 'images/crops/default.jpg';
        };
    }
    
    // Update farming tips
    if (farmingTips && cropData.tips) {
        farmingTips.innerHTML = '';
        cropData.tips.forEach(tip => {
            const li = document.createElement('li');
            li.textContent = tip;
            farmingTips.appendChild(li);
        });
    }
});