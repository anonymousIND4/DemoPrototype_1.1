// Language translations
const translations = {
    'en': {
        'nav_home': 'Home',
        'nav_about': 'About',
        'nav_services': 'Services',
        'nav_news': 'News',
        'nav_contact': 'Contact',
        'hero_title': 'AgroAI – Smart Crop Advisor',
        'hero_subtitle': 'AI-powered crop recommendations for farmers',
        'get_started': 'Get Started',
        'how_helps': 'How AgroAI Helps You',
        'crop_recommendation': 'Crop Recommendation',
        'crop_recommendation_text': 'Get AI-powered suggestions for the best crops to grow based on your soil conditions.',
        'weather_updates': 'Weather Updates',
        'weather_updates_text': 'Stay informed about weather conditions affecting your farming decisions.',
        'fertilizer_advice': 'Fertilizer Advice',
        'fertilizer_advice_text': 'Receive personalized fertilizer recommendations for optimal crop growth.',
        'gallery_title': 'Smart Farming in Action',
        'gallery_item1_title': 'Modern Farming Landscape',
        'gallery_item1_text': 'Sustainable agricultural practices for better yields',
        'gallery_item2_title': 'AI-Powered Agriculture',
        'gallery_item2_text': 'Using technology to optimize crop production',
        'cta_title': 'Ready to Optimize Your Farm?',
        'cta_text': 'Use our AI-powered tool to get personalized crop recommendations.',
        'cta_button': 'Get Crop Recommendations',
        'footer_text': 'AI-powered crop recommendations for farmers.',
        'contact_us': 'Contact Us',
        'follow_us': 'Follow Us',
        'copyright': '© 2023 AgroAI – Smart Crop Advisor. All rights reserved.'
    },
    'hi': {
        'nav_home': 'होम',
        'nav_about': 'हमारे बारे में',
        'nav_services': 'सेवाएं',
        'nav_news': 'समाचार',
        'nav_contact': 'संपर्क',
        'hero_title': 'एग्रोएआई – स्मार्ट फसल सलाहकार',
        'hero_subtitle': 'किसानों के लिए एआई-संचालित फसल सिफारिशें',
        'get_started': 'शुरू करें',
        'how_helps': 'एग्रोएआई आपकी कैसे मदद करता है',
        'crop_recommendation': 'फसल अनुशंसा',
        'crop_recommendation_text': 'अपनी मिट्टी की स्थिति के आधार पर उगाने के लिए सर्वोत्तम फसलों के लिए एआई-संचालित सुझाव प्राप्त करें।',
        'weather_updates': 'मौसम अपडेट',
        'weather_updates_text': 'अपने कृषि निर्णयों को प्रभावित करने वाली मौसम की स्थिति के बारे में जानकारी रखें।',
        'fertilizer_advice': 'उर्वरक सलाह',
        'fertilizer_advice_text': 'इष्टतम फसल विकास के लिए व्यक्तिगत उर्वरक सिफारिशें प्राप्त करें।',
        'gallery_title': 'स्मार्ट खेती कार्रवाई में',
        'gallery_item1_title': 'आधुनिक कृषि परिदृश्य',
        'gallery_item1_text': 'बेहतर उपज के लिए टिकाऊ कृषि प्रथाएं',
        'gallery_item2_title': 'एआई-संचालित कृषि',
        'gallery_item2_text': 'फसल उत्पादन को अनुकूलित करने के लिए प्रौद्योगिकी का उपयोग',
        'cta_title': 'अपने खेत को अनुकूलित करने के लिए तैयार हैं?',
        'cta_text': 'व्यक्तिगत फसल सिफारिशें प्राप्त करने के लिए हमारे एआई-संचालित उपकरण का उपयोग करें।',
        'cta_button': 'फसल सिफारिशें प्राप्त करें',
        'footer_text': 'किसानों के लिए एआई-संचालित फसल सिफारिशें।',
        'contact_us': 'संपर्क करें',
        'follow_us': 'हमें फॉलो करें',
        'copyright': '© 2023 एग्रोएआई – स्मार्ट फसल सलाहकार। सर्वाधिकार सुरक्षित।'
    },
    'ta': {
        'nav_home': 'முகப்பு',
        'nav_about': 'எங்களை பற்றி',
        'nav_services': 'சேவைகள்',
        'nav_news': 'செய்திகள்',
        'nav_contact': 'தொடர்பு',
        'hero_title': 'அக்ரோஏஐ – ஸ்மார்ட் பயிர் ஆலோசகர்',
        'hero_subtitle': 'விவசாயிகளுக்கான AI-இயக்கப்பட்ட பயிர் பரிந்துரைகள்',
        'get_started': 'தொடங்குங்கள்',
        'how_helps': 'அக்ரோஏஐ உங்களுக்கு எவ்வாறு உதவுகிறது',
        'crop_recommendation': 'பயிர் பரிந்துரை',
        'crop_recommendation_text': 'உங்கள் மண் நிலைமைகளின் அடிப்படையில் வளர்ப்பதற்கான சிறந்த பயிர்களுக்கான AI-இயக்கப்பட்ட பரிந்துரைகளைப் பெறுங்கள்.',
        'weather_updates': 'வானிலை புதுப்பிப்புகள்',
        'weather_updates_text': 'உங்கள் விவசாய முடிவுகளை பாதிக்கும் வானிலை நிலைமைகளைப் பற்றி தெரிந்து கொள்ளுங்கள்.',
        'fertilizer_advice': 'உர ஆலோசனை',
        'fertilizer_advice_text': 'உகந்த பயிர் வளர்ச்சிக்கான தனிப்பயனாக்கப்பட்ட உர பரிந்துரைகளைப் பெறுங்கள்.',
        'gallery_title': 'ஸ்மார்ட் விவசாயம் செயலில்',
        'gallery_item1_title': 'நவீன விவசாய நிலப்பரப்பு',
        'gallery_item1_text': 'சிறந்த மகசூலுக்கான நிலையான விவசாய நடைமுறைகள்',
        'gallery_item2_title': 'AI-இயக்கப்பட்ட விவசாயம்',
        'gallery_item2_text': 'பயிர் உற்பத்தியை உகந்ததாக்க தொழில்நுட்பத்தைப் பயன்படுத்துதல்',
        'cta_title': 'உங்கள் பண்ணையை உகந்ததாக்க தயாரா?',
        'cta_text': 'தனிப்பயனாக்கப்பட்ட பயிர் பரிந்துரைகளைப் பெற எங்கள் AI-இயக்கப்பட்ட கருவியைப் பயன்படுத்தவும்.',
        'cta_button': 'பயிர் பரிந்துரைகளைப் பெறுங்கள்',
        'footer_text': 'விவசாயிகளுக்கான AI-இயக்கப்பட்ட பயிர் பரிந்துரைகள்.',
        'contact_us': 'எங்களை தொடர்பு கொள்ள',
        'follow_us': 'எங்களை பின்தொடரவும்',
        'copyright': '© 2023 அக்ரோஏஐ – ஸ்மார்ட் பயிர் ஆலோசகர். அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.'
    },
    'te': {
        'nav_home': 'హోమ్',
        'nav_about': 'మా గురించి',
        'nav_services': 'సేవలు',
        'nav_news': 'వార్తలు',
        'nav_contact': 'సంప్రదించండి',
        'hero_title': 'అగ్రోఏఐ – స్మార్ట్ పంట సలహాదారు',
        'hero_subtitle': 'రైతులకు AI-ఆధారిత పంట సిఫార్సులు',
        'get_started': 'ప్రారంభించండి',
        'how_helps': 'అగ్రోఏఐ మీకు ఎలా సహాయపడుతుంది',
        'crop_recommendation': 'పంట సిఫార్సు',
        'crop_recommendation_text': 'మీ నేల పరిస్థితుల ఆధారంగా పెంచడానికి ఉత్తమ పంటల కోసం AI-ఆధారిత సూచనలను పొందండి.',
        'weather_updates': 'వాతావరణ నవీకరణలు',
        'weather_updates_text': 'మీ వ్యవసాయ నిర్ణయాలను ప్రభావితం చేసే వాతావరణ పరిస్థితుల గురించి తెలుసుకోండి.',
        'fertilizer_advice': 'ఎరువుల సలహా',
        'fertilizer_advice_text': 'అనుకూలమైన పంట వృద్ధి కోసం వ్యక్తిగతీకరించిన ఎరువుల సిఫార్సులను పొందండి.',
        'gallery_title': 'స్మార్ట్ వ్యవసాయం చర్యలో',
        'gallery_item1_title': 'ఆధునిక వ్యవసాయ భూదృశ్యం',
        'gallery_item1_text': 'మెరుగైన దిగుబడుల కోసం స్థిరమైన వ్యవసాయ పద్ధతులు',
        'gallery_item2_title': 'AI-ఆధారిత వ్యవసాయం',
        'gallery_item2_text': 'పంట ఉత్పత్తిని అనుకూలీకరించడానికి సాంకేతికతను ఉపయోగించడం',
        'cta_title': 'మీ పొలాన్ని అనుకూలీకరించడానికి సిద్ధంగా ఉన్నారా?',
        'cta_text': 'వ్యక్తిగతీకరించిన పంట సిఫార్సులను పొందడానికి మా AI-ఆధారిత సాధనాన్ని ఉపయోగించండి.',
        'cta_button': 'పంట సిఫార్సులను పొందండి',
        'footer_text': 'రైతులకు AI-ఆధారిత పంట సిఫార్సులు.',
        'contact_us': 'మమ్మల్ని సంప్రదించండి',
        'follow_us': 'మమ్మల్ని అనుసరించండి',
        'copyright': '© 2023 అగ్రోఏఐ – స్మార్ట్ పంట సలహాదారు. అన్ని హక్కులు రిజర్వ్ చేయబడ్డాయి.'
    }
};

// Set default language
let currentLang = localStorage.getItem('language') || 'en';

// Initialize language on page load
document.addEventListener('DOMContentLoaded', function() {
    // Set initial language
    setLanguage(currentLang);
    
    // Update active language in dropdown
    updateActiveLanguage(currentLang);
    
    // Add click event to language button to toggle dropdown
    const langBtn = document.querySelector('.lang-btn');
    const langDropdown = document.querySelector('.lang-dropdown');
    
    langBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        langDropdown.style.display = langDropdown.style.display === 'block' ? 'none' : 'block';
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function() {
        langDropdown.style.display = 'none';
    });
    
    // Add event listeners to language options
    const langOptions = document.querySelectorAll('.lang-dropdown li');
    langOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.stopPropagation();
            const lang = this.getAttribute('data-lang');
            
            // Check if we have translations for this language
            if (translations[lang]) {
                // Use local translations
                setLanguage(lang);
                updateActiveLanguage(lang);
            } else {
                // Use API translation if available
                if (typeof translatePageWithAPI === 'function') {
                    translatePageWithAPI(lang);
                    // updateActiveLanguage is called inside translatePageWithAPI
                } else {
                    setLanguage(lang);
                    updateActiveLanguage(lang);
                }
            }
            // Close dropdown after selection
            langDropdown.style.display = 'none';
        });
    });
    
    // Initial translation of the page
    updateContent();
});

// Function to set language
function setLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('language', lang);
    
    // Update current language display
    const currentLangElement = document.querySelector('.current-lang');
    if (currentLangElement) {
        currentLangElement.textContent = lang.toUpperCase();
    }
    
    // Update page content
    updateContent();
}

// Function to update active language in dropdown
function updateActiveLanguage(lang) {
    const langOptions = document.querySelectorAll('.lang-dropdown li');
    langOptions.forEach(option => {
        if (option.getAttribute('data-lang') === lang) {
            option.classList.add('active');
        } else {
            option.classList.remove('active');
        }
    });
}

// Function to update page content based on selected language
function updateContent() {
    const elements = document.querySelectorAll('[data-i18n]');
    
    elements.forEach(element => {
        const key = element.getAttribute('data-i18n');
        
        if (translations[currentLang] && translations[currentLang][key]) {
            // Handle different element types
            if (element.tagName === 'INPUT' && element.type === 'submit') {
                element.value = translations[currentLang][key];
            } else if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = translations[currentLang][key];
            } else {
                element.textContent = translations[currentLang][key];
            }
        }
    });
}

// Call updateContent immediately if DOM is already loaded
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(function() {
        setLanguage(currentLang);
        updateActiveLanguage(currentLang);
        updateContent();
    }, 1);
}