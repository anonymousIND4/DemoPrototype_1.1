// JavaScript for News Page with News API integration

document.addEventListener('DOMContentLoaded', function() {
    // News API Key
    const newsApiKey = '06c6724f955643038a774378648bceb9';
    const newsApiUrl = 'https://newsapi.org/v2/everything';
    
    // Function to fetch news from the API
    async function fetchAgricultureNews() {
        try {
            const response = await fetch(`${newsApiUrl}?q=agriculture+farming+crops&apiKey=${newsApiKey}&language=en&pageSize=6`);
            const data = await response.json();
            
            if (data.status === 'ok') {
                displayNews(data.articles);
            } else {
                console.error('Error fetching news:', data.message);
            }
        } catch (error) {
            console.error('Error fetching news:', error);
        }
    }
    
    // Function to display news in the news grid
    function displayNews(articles) {
        const newsGrid = document.querySelector('.news-grid');
        
        // Only proceed if we found the news grid
        if (!newsGrid) return;
        
        // Clear existing static news cards
        newsGrid.innerHTML = '';
        
        // Create a card for each article
        articles.forEach((article, index) => {
            // Create date object from the published date
            const pubDate = new Date(article.publishedAt);
            const day = pubDate.getDate();
            const month = pubDate.toLocaleString('default', { month: 'short' });
            
            // Determine category (can be enhanced with better categorization logic)
            const categories = ['Technology', 'Sustainability', 'Policy', 'Weather', 'Market', 'Success Story'];
            const category = categories[index % categories.length];
            
            // Create the news card HTML
            const newsCard = document.createElement('article');
            newsCard.className = 'news-card';
            newsCard.innerHTML = `
                <div class="news-image">
                    <img src="${article.urlToImage || 'images/news/news' + (index + 1) + '.svg'}" alt="${article.title}">
                    <div class="news-date">
                        <span class="day">${day}</span>
                        <span class="month">${month}</span>
                    </div>
                </div>
                <div class="news-content">
                    <div class="news-category">${category}</div>
                    <h3>${article.title}</h3>
                    <p>${article.description || 'Click to read more about this agricultural news story.'}</p>
                    <a href="${article.url}" class="read-more" target="_blank">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            `;
            
            // Handle image loading errors
            const img = newsCard.querySelector('img');
            img.onerror = function() {
                this.src = `images/news/news${(index % 6) + 1}.svg`;
            };
            
            // Add the card to the grid
            newsGrid.appendChild(newsCard);
        });
    }
    
    // Initialize news fetching
    fetchAgricultureNews();
    
    // Newsletter subscription form handling
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value.trim();
            
            if (email) {
                // Here you would typically send this to your backend
                alert(`Thank you for subscribing with ${email}! You'll receive our latest agricultural news and updates.`);
                emailInput.value = '';
            }
        });
    }
});